const currentDateView = document.getElementById('currentdate');
const ratesView = document.getElementById('rates');
const rateHistoryView = document.getElementById('ratehistory');
